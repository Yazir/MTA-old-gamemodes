if not getResourceFromName("freecam") then return end


addCommandHandler("freecam", function()
	if exports.freecam:isFreecamEnabled() then
		exports.freecam:setFreecamDisabled()
		setCameraTarget(me,me)
	else
		exports.freecam:setFreecamEnabled()
	end
end)